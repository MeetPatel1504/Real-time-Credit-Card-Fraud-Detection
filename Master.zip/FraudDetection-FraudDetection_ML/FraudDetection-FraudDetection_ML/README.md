# Real time Credit card FraudDetection

Credit card fraud detection Domain Knowledge
Let's say you own a credit card. Your prior spending habits will be learned. Like how much amount you spend, at which merchant you spend, at what frequency you spend, what do you purchase, etc. 
Based on this learning, your current credit transaction will be predicted as fraud if it deviates from your earlier spending habits otherwise it will be treated as a genuine transaction. And fraud transaction will be alerted in the dashboard. 

Such predictions will be done on millions of transaction. Hence distributed frameworks are used which can scale as the transactions increases.


Real time Creditcard Fruad detection using Spark2.2, Kafka, Cassandra. Automation of Spark Jobs using Airflow Automation.
Discount Coupon Link: https://www.udemy.com/real-time-creditcard-fraud-detection-using-spark/?couponCode=DIS640
